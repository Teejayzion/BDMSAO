import numpy as np
import random
from copy import deepcopy
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
import math,time,sys
from matplotlib import pyplot
import pandas as pd
from datetime import datetime
from functools import partial
import seaborn as sns
from sklearn.metrics import roc_auc_score
from sklearn.neural_network import MLPClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn import preprocessing
from sklearn.ensemble import RandomForestClassifier
from sklearn import preprocessing
from sklearn.metrics import roc_curve, auc, roc_auc_score
from sklearn.metrics import f1_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import precision_recall_curve
import time

omega =  0.99


def initialise(partCount, dim, trainX, testX, trainy, testy):
    population=np.zeros((partCount,dim))
    minn = 1
    maxx = math.floor(0.5*dim)

    if maxx<minn:
        maxx = minn + 1

    for i in range(partCount):
        random.seed(i**3 + 10 + time.time() )
        no = random.randint(minn,maxx)
        if no == 0:
            no = 1
        random.seed(time.time()+ 100)
        pos = random.sample(range(0,dim-1),no)
        for j in pos:
            population[i][j]=1

    return population

def fitness(agent, trainX, testX, trainy, testy):

    cols=np.flatnonzero(agent)

    val=1
    if np.shape(cols)[0]==0:
        return val
    clf=KNeighborsClassifier(n_neighbors=5)

    train_data=trainX[:,cols]
    test_data=testX[:,cols]
    clf.fit(train_data,trainy)
    val=1-clf.score(test_data,testy)


    set_cnt=sum(agent)
    set_cnt=set_cnt/np.shape(agent)[0]
    val=omega*val+(1-omega)*set_cnt
    return val

def allfit(pop, trainX, testX, trainy, testy):
    fit = np.zeros((len(pop), 1))
    for p in range(len(pop)):
        fit[p] = fitness(pop[p], trainX, testX, trainy, testy)
    return fit

def test_accuracy(agent, trainX, testX, trainy, testy):
    cols=np.flatnonzero(agent)
    val=1
    if np.shape(cols)[0]==0:
        return val

    clf=KNeighborsClassifier(n_neighbors=5)

    train_data=trainX[:,cols]
    test_data=testX[:,cols]
    clf.fit(train_data,trainy)
    val=clf.score(test_data,testy)
    return val

def onecnt(agent):
    return sum(agent)

def sigmoid(gamma):
    if gamma < 0:
        return 1 - 1/(1 + math.exp(gamma))
    else:
        return 1/(1 + math.exp(-gamma))

def bestAgent(fit):
    ind = np.argsort(fit, axis=0)
    return ind[0]


def randomwalk(agent):
    percent = 30
    percent /= 100
    neighbor = agent.copy()
    size = np.shape(agent)[0]
    upper = int(percent*size)
    if upper <= 1:
        upper = size
    x = random.randint(1,upper)
    pos = random.sample(range(0,size - 1),x)
    for i in pos:
        neighbor[i] = 1 - neighbor[i]
    return neighbor

## Simulated Anealing
def SA(agent, fitAgent, trainX, testX, trainy, testy):
    # initialise temprature
    T = 4*np.shape(agent)[0]; T0 = 2*np.shape(agent)[0];

    S = agent.copy();
    bestSolution = agent.copy();
    bestFitness = fitAgent;

    while T > T0:
        neighbor = randomwalk(S)
        neighborFitness = fitness(neighbor, trainX, testX, trainy, testy)

        if neighborFitness < bestFitness:
            S = neighbor.copy()
            bestSolution = neighbor.copy()
            bestFitness = neighborFitness

        elif neighborFitness == bestFitness:
            if np.sum(neighbor) == np.sum(bestSolution):
                S = neighbor.copy()
                bestSolution = neighbor.copy()
                bestFitness = neighborFitness

        else:
            theta = neighborFitness - bestFitness
            if np.random.rand() < math.exp(-1*(theta/T)):
                S = neighbor.copy()

        T *= 0.925

    return bestSolution, bestFitness

def BDMO_fitness(agent, trainX, testX, trainy, testy):

    cols=np.flatnonzero(agent)

    val=1
    if np.shape(cols)[0]==0:
        return val, 1-val
    clf=KNeighborsClassifier(n_neighbors=5)

    train_data=trainX[:,cols]
    test_data=testX[:,cols]
    clf.fit(train_data,trainy)
    val=1-clf.score(test_data,testy)


    set_cnt=sum(agent)
    set_cnt=set_cnt/np.shape(agent)[0]
    val=omega*val+(1-omega)*set_cnt
    return val, 1-val

def BDMO_allfit(pop, trainX, testX, trainy, testy):
    acc = np.zeros((len(pop), 1))
    cost = np.zeros((len(pop), 1))
    for p in range(len(pop)):
        acc[p], cost[p] = BDMO_fitness(pop[p], trainX, testX, trainy, testy)
    return acc, cost

def RouletteWheelSelection(P):
    C=sum(P)
    r = np.random.uniform(low=0, high=C)
    for idx, f in enumerate(P):
            r = r + f
            if r > C:
                return idx
    return np.random.choice(range(0, len(P)))
    #r=np.random.rand()  #random.randint
    #i=np.where(r <= C, 1, r) #find(r<=C,1,'first')   #np.nonzero(x)
    #return i

def BDMO(dataset, pop_size, MaxIter, isSA):
    df = pd.read_csv(dataset)
    a, b = np.shape(df)

    data = df.values[:,0:b-1]
    label = df.values[:,b-1]
    dimension = data.shape[1]
    
    cross = 5
    test_size = (1/cross)

    trainX, testX, trainy, testy = train_test_split(data, label,stratify=label ,test_size=test_size,random_state=(7+17*int(time.time()%1000)))

    clf=KNeighborsClassifier(n_neighbors=5)
    clf.fit(trainX,trainy)
    val=clf.score(testX,testy)

    #Variable initialaization
    nVar=dimension             #Number of Decision Variables
    VarSize=[]           #Decision Variables Matrix Size  1:nVar
    VarMin=0             #Decision Variables Lower Bound
    VarMax=1             #Decision Variables Upper Bound
    nBabysitter= 1           #Number of babysitters
    nAlphaGroup=pop_size - nBabysitter         #Number of Alpha group
    nScout=nAlphaGroup         #Number of Scouts
    L=round(0.6*nVar*nBabysitter)  #Babysitter Exchange Parameter 
    peep=1             #Alpha female \.12s vocalization 
    tau=random.uniform(0, 1)
    sm=[]
    TestaccG=None
    

    #Population iniitalization and fitting, mongoose strucure initialization
    #Empty Mongoose Structure
    Position=[]
    Cost=[]
    Acc=[]
    pop = initialise(pop_size, dimension, trainX, testX, trainy, testy)
    Position=pop
    Acc, Cost=BDMO_allfit(pop, trainX, testX, trainy, testy)
    bestagent_acc, best_fit = BDMO_fitness(pop[0], trainX, testX, trainy, testy)
    best_agent= pop[0]
    
    
    #Abandonment Counter
    C=np.zeros((nAlphaGroup,1))
    Iter=1
    CF=(1-Iter/MaxIter) ** (2*Iter/MaxIter)  #np.linalg.matrix_power((1-Iter/MaxIter), (2*Iter/MaxIter))

    #Array to Hold Best Cost Values
    curve=np.zeros((MaxIter,1))
    allfit=[]
    
    BestSol=pop[0]
    #DMOA Main Loop
    for Iter in range(MaxIter):
        #Alpha group
        F=np.zeros((nAlphaGroup,1))
        MeanCost = np.mean(Cost)
        for i in range(nAlphaGroup):
            # Calculate Fitness Values and Selection of Alpha
            F[i] = np.exp(-Cost[i]/MeanCost);   #Convert Cost to Fitness

        P=F/sum(F);
        
        if isSA:
            #########################################################
            # LOCAL SEARCH
            ########################################################
            for i in range(pop_size):
                pop[i], Cost[i] = SA(pop[i], Cost[i], trainX, testX, trainy, testy)
        else:
            #Foraging led by Alpha female
            for m in range(nAlphaGroup):
                i=RouletteWheelSelection(P) #Select Alpha female        
                #Choose k randomly, not equal to Alpha
                #K=np.empty([i-1, nAlphaGroup]) #1:i-1, i+1:nAlphaGroup  ???
                rand=random.randint(1, nAlphaGroup)  #random.randint(1, K.size)
                k=rand #K[rand]
            
                #Define Vocalization Coeff.
                phi=(peep/2) * np.random.uniform(-1,+1,VarSize)
            
                # New Mongoose Position
                newpop_Position=pop[i] + phi * (pop[i] - pop[k])
                
                #Check boundary VarMin,VarMax
                #         for j=1:size(X,2)   
                Flag_UB=newpop_Position > VarMax    #check if they exceed (up) the boundaries
                Flag_LB=newpop_Position < VarMin     #check if they exceed (down) the boundaries
                newpop_Position=(newpop_Position * (~(Flag_UB+Flag_LB))) + (VarMax * Flag_UB) + (VarMin * Flag_LB);
    
                #Evaluation
                newpop_Acc, newpop_Cost= BDMO_fitness(newpop_Position, trainX, testX, trainy, testy)  #CostFunction(X,Y,(newpop.Position > 0.5),HO); ???
                
                #Comparision
                if newpop_Cost <= Cost[i]:
                    pop[i]=newpop_Position
                else:
                    C[i]=C[i]+1
                    
        #Scout group
        for i in range(nScout):
            #Choose k randomly, not equal to i
            #K=np.empty([i-1, nAlphaGroup]) #1:i-1, i+1:nAlphaGroup ???
            rand=random.randint(1, nAlphaGroup)  #random.randint(1, K.size)
            k=rand #K[rand]
        
            #Define Vocalization Coeff.
            phi=(peep/2) * np.random.uniform(-1,+1,VarSize)
        
            #New Mongoose Position
            newpop_Position=pop[i] + phi * (pop[i] - pop[k])
            
            #Check boundary
            Flag_UB=newpop_Position > VarMax     #check if they exceed (up) the boundaries
            Flag_LB=newpop_Position < VarMin     #check if they exceed (down) the boundaries
            newpop_Position=(newpop_Position * (~(Flag_UB+Flag_LB))) + (VarMax * Flag_UB) + (VarMin * Flag_LB)
            
            #Evaluation
            newpop_Acc, newpop_Cost= BDMO_fitness(newpop_Position, trainX, testX, trainy, testy) #CostFunction(X,Y,(newpop.Position > 0.5),HO); ???
            
            #Sleeping mould
            sm.append((newpop_Cost - Cost[i])/max(newpop_Cost, Cost[i]))
            
            #Comparision
            if newpop_Cost <= Cost[i]:
                pop[i]=newpop_Position
            else:
                C[i]=C[i] + 1
        
        #Babysitters
        for i in range(1, nBabysitter):
            newtau=np.mean(sm)
            if C[i] >= L:
                #pop (i).Position=unifrnd(VarMin,VarMax,VarSize);
                #pop (i).Cost=benchmark_functions(pop (i).Position,Function_name,dim);
                M=(pop[i] * sm)/pop[i]
                if newtau < tau:
                   newpop_Position=pop[i] - CF * phi * np.random.rand() * (pop[i] - M)
                else:
                   newpop_Position=pop[i] + CF * phi * np.random.rand() * (pop[i] - M)
                
                tau=newtau
                Flag_UB=newpop_Position > VarMax     #% check if they exceed (up) the boundaries
                Flag_LB=newpop_Position < VarMin     #% check if they exceed (down) the boundaries
                newpop_Position=(newpop_Position * (~(Flag_UB+Flag_LB))) + (VarMax * Flag_UB) + (VarMin * Flag_LB)
                C[i]=0
                
        #Update Best Solution Ever Found
        for i in range(1, nAlphaGroup):
           if Cost[i] <=  best_fit:
               BestSol=pop[i]
        
        #Store Best Cost Ever Found
        curve[Iter]=best_fit
        allfit.append(best_fit)
        runtime=time.time()
        #Display Iteration Information        
        print('Iteration ', str(Iter),  ': Best Cost = ',  str(curve[Iter]))
    
    testAcc = test_accuracy(BestSol, trainX, testX, trainy, testy)
    featCnt = onecnt(BestSol)

    return curve, testAcc, featCnt, BestSol

# -*- coding: utf-8 -*-
"""
Created on Tue Jun 21 05:14:25 2022

@author: Oyelade
"""
import numpy as np
from convergencePlot import plot_convergence, save_results_to_csv, save_best_fit
from time import time
from BDMO import BDMO

#import GNDO

from WOA import WOA
 

if __name__ == "__main__":
    #Number of iterations
    MaxIter = 50
    
    #Variouse population sizes you want to investigate with
    p_size = [10]
    
    #Select the population size that you want to use to plot all
    #the convergence graph for fit vs iteration. Note that: p_size[3]=50 population
    selected_fit_pop=p_size[0] 
    method_fit_pop=None
    
    #All datasets to be used for experimentation
    datasetlist = ["Prostate.csv", 
                    #"BreastEW.csv", "BreastCancer.csv",
                    #"CongressEW.csv", "Exactly.csv", "Exactly2.csv", "HeartEW.csv", "Ionosphere.csv", "Lymphography.csv", "M-of-n.csv", "PenglungEW.csv", "Sonar.csv", "SpectEW.csv", "Tic-tac-toe.csv", "Vote.csv", "Wine.csv", "Zoo.csv","KrVsKpEW.csv", "WaveformEW.csv" 
                    ]
    
    #All algorithms to be experimented with
    algorithms=[ 'BDMO_SA', 'WOA',
                # 'GNDO_SA', 'ASGW', 'HSGW',  'SFO', 'WOA','PSO', 
               
                ]
    i=0
    for filename  in datasetlist:
        accdata={}
        fitdata={}   
            
        for method in algorithms:
            start_time=time()
            acc_pop=[]
            for pop_size in p_size:
                fit_pop={}
                resulfilename=method
                datasetname='./UCI_datasets/'+filename
                accuArr = []
                featArr = []
                agenArr = []
                allfitArr = []
                
                for i in range(10): #Run 10 times, you can change it to any number of runs
                    print('>>>Experiement:'+method+' with '+filename+', popsize:'+str(pop_size)+', run:'+str(i+1))
                    if method=='BDMO':
                        allfit, testAcc, featCnt, gbest = BDMO(datasetname, pop_size, MaxIter, False)
                    if method=='BDMO_SA':
                        allfit, testAcc, featCnt, gbest = BDMO(datasetname, pop_size, MaxIter, True)
                     
                    if method=='WOA':    
                        allfit, testAcc, featCnt, gbest= WOA(datasetname, pop_size, MaxIter)
                                        
                    accuArr.append(testAcc)
                    featArr.append(featCnt)
                    allfitArr.append(allfit)
                    agenArr.append(gbest)
                    run_item={
                    'dataset':filename,
                    'algorithm': method,
                    'popsize': pop_size,
                    'run_no': i,
                    'iteration':MaxIter,
                    'testAcc':testAcc,
                    'FeatureCount':featCnt,
                    'fitness':allfit,
                    'best':gbest,
                    }
                    save_results_to_csv(run_item, filename+method, './results/Runs/')
                    
                maxxAcc = max(accuArr)
                acc_pop.append(maxxAcc)
                fit_pop[pop_size]=allfitArr[0]
                if selected_fit_pop == pop_size:
                    method_fit_pop=allfitArr[0]
                    
                k = np.argsort(accuArr)
                bagent = agenArr[k[-1]]
                currFeat= 20000
                for i in range(np.shape(accuArr)[0]):
                    if accuArr[i]==maxxAcc and featArr[i] < currFeat:
                        currFeat = featArr[i]
                        bagent = agenArr[i]
                datasetname = datasetname.split('.')[0]
                print('Best: ', maxxAcc,currFeat)
                save_best_fit('./results/bests/', resulfilename, datasetname, method, pop_size, maxxAcc, currFeat)
                
                
            time_required = time() - start_time
            accdata[method]=acc_pop
            fitdata[method]=method_fit_pop
            item={
                    'dataset':filename,
                    'algorithm': method,
                    'popsize': p_size,
                    'iteration':MaxIter,
                    'allfits':fit_pop,
                    'allacc':acc_pop,
                    'computation_time':time_required,
                    }
            save_results_to_csv(item, filename+method, './results/')
            
            #END of all methods for a particular dataset
            #plot accuracy
        pathsave='./results/Accuracy/'
        plotfilename=method+'_acc_'+filename
        plot_convergence('Accuracy - '+filename, 'Accuracy', 'Population Size', pathsave, 
                         plotfilename, accdata, p_size, algorithms)
        #plot fitness
        pathsave='./results/Fit/'
        plotfilename=method+'_acc_'+filename
        plot_convergence('Convergence - '+filename, 'Fitness', 'Iteration', pathsave, 
                         plotfilename, fitdata, np.arange(MaxIter), algorithms)
        i=i+1
